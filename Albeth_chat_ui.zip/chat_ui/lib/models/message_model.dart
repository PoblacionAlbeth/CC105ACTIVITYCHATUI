import 'package:chat_ui/models/user_model.dart';

class Message {
  final User sender;
  final String time; //Would usually be type DateTime or Firebase
  final String text;
  final bool isLiked;
  final bool unread;

  Message({
    this.sender,
    this.time,
    this.text,
    this.isLiked,
    this.unread,
  });
}

//YOU - current user
final User currentUser =
    User(id: 0, name: 'Current User', imageUrl: 'assets/images/Milk.png');

final User Dojin =
    User(id: 1, name: 'Dojin', imageUrl: 'assets/images/Dojin.png');

final User Glen = User(id: 2, name: 'Glen', imageUrl: 'assets/images/Glen.jpg');

final User Howl = User(id: 3, name: 'Howl', imageUrl: 'assets/images/Howl.png');

final User McQueen =
    User(id: 4, name: 'McQueen', imageUrl: 'assets/images/McQueen.png');

final User Shizuma =
    User(id: 5, name: 'Shizuma', imageUrl: 'assets/images/Shizuma.png');

List<User> favorites = [Dojin, Glen, Howl, McQueen, Shizuma];

List<Message> chats = [
  Message(
    sender: Dojin,
    time: '7:00 AM',
    text: 'Milk, can you babysit Byul For today?',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: Glen,
    time: '12:00 PM',
    text: 'Good Day Miss Milk, I found the package...',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: Howl,
    time: '8:45 PM',
    text: 'Hey! When are you visiting? We miss you.',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: McQueen,
    time: '08:49 AM',
    text: 'Planning on surprising Glen on his Birthday. Any Ideas?.',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: Shizuma,
    time: '10:50 PM',
    text: 'Waaah.Miiiiiilk. My GF dumped me T^T.',
    isLiked: false,
    unread: false,
  ),
];

//Chat screen
List<Message> messages = [
  Message(
    sender: currentUser,
    time: '4:16 PM',
    text: 'Dojin,They miss you. Of course you can come.',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: Dojin,
    time: '4:13 PM',
    text: 'Can we really join?',
    isLiked: true,
    unread: true,
  ),
  Message(
    sender: currentUser,
    time: '4:10 PM',
    text:
        'OMG! Great timing. The Gang is going to Tagaytay next week for Glens Birthday. You guys need to come! ',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: Dojin,
    time: '4:07 PM',
    text:
        'Actually,The Missus wants to go on a trip. We are trying to find a great place to unwind for the week. Do you know a place?',
    isLiked: true,
    unread: true,
  ),
  Message(
    sender: currentUser,
    time: '4:05 PM',
    text: 'Anything for the cute little star. What are you doing today?',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: Dojin,
    time: '4:00 PM',
    text: 'Good Day Milk, Thank you babysitting byul yesterday.',
    isLiked: false,
    unread: false,
  ),
];
